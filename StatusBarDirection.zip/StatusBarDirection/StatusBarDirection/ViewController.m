//
//  ViewController.m
//  StatusBarDirection
//
//  Created by 韩智星 on 2017/3/15.
//  Copyright © 2017年 韩智星. All rights reserved.
//

#import "ViewController.h"

#define ScreenH [UIScreen mainScreen].bounds.size.height
#define ScreenW [UIScreen mainScreen].bounds.size.width
#define set_frame(viewX,viewY,viewW,viewH) (CGRect){viewX,viewY,viewW,viewH}//设置坐标(可修改)
#define videoH 200
@interface ViewController ()
{
    BOOL _screen;
    UIInterfaceOrientation _currentOrientation;
}
@property (nonatomic,assign) NSInteger index;
@property (nonatomic,weak) UIImageView *backView;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    _screen = NO;
    [[UIDevice currentDevice] beginGeneratingDeviceOrientationNotifications];
    _index = 0;
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(Orientation:) name:UIDeviceOrientationDidChangeNotification object:nil];
    
    UIImageView *backView= [[UIImageView alloc] initWithFrame:set_frame(0, 0, ScreenW, videoH)];
    _backView = backView;
    backView.image = [UIImage imageNamed:@"2016.jpg"];
    _backView.backgroundColor = [UIColor blackColor];
    [self.view addSubview:backView];
     [UIApplication sharedApplication].statusBarStyle = UIStatusBarStyleLightContent;
    
}
-(void)Orientation:(NSNotification*)note
{

    if (_screen)
    {
        UIDevice *device = [UIDevice currentDevice];
        if (device.orientation == UIDeviceOrientationLandscapeLeft||device.orientation == UIDeviceOrientationLandscapeRight)
        {
            [UIView animateWithDuration:0.5 animations:^{
                
                _backView.transform = [self getOrientation:(UIInterfaceOrientation)device.orientation];
            }];
        }
        
    }
}
-(CGAffineTransform)getOrientation:(UIInterfaceOrientation)orientation{
    
    if (orientation == UIInterfaceOrientationPortrait) {
        _currentOrientation = UIInterfaceOrientationPortrait;
        [self toPortraitUpdate];
        return CGAffineTransformIdentity;
    } else if (orientation == UIInterfaceOrientationLandscapeLeft){
        _currentOrientation = UIInterfaceOrientationLandscapeLeft;
        [self toPortraitUpdate];
        return CGAffineTransformMakeRotation(-M_PI_2);
    } else if (orientation == UIInterfaceOrientationLandscapeRight){
        _currentOrientation = UIInterfaceOrientationLandscapeRight;
        [self toPortraitUpdate];
        return CGAffineTransformMakeRotation(M_PI_2);
    } else if (orientation == UIInterfaceOrientationPortraitUpsideDown) {
        _currentOrientation = UIInterfaceOrientationPortraitUpsideDown;
        [self toPortraitUpdate];
        return CGAffineTransformMakeRotation(M_PI);
    }

    return CGAffineTransformIdentity;
}
-(void)toPortraitUpdate{
 
    //处理状态条
    [[UIApplication sharedApplication] setStatusBarOrientation:_currentOrientation animated:YES];
    [[UIApplication sharedApplication] setStatusBarHidden:NO];
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent];

}

-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
   
    _backView.center = self.view.center;
    _index++;
    if (_index%2==0) {//半屏
        
        NSLog(@"ScreenW==%f  ScreenH==%f",ScreenW,ScreenH);
         [[UIApplication sharedApplication] setStatusBarOrientation:UIInterfaceOrientationPortrait animated:YES];
        [UIView animateWithDuration:0.5 animations:^{
            
        _backView.transform = CGAffineTransformMakeRotation(0);
        _backView.frame = CGRectMake(0, 0, ScreenW, videoH);
        
        }];
        _screen = NO;
    }else//全屏
    {
        
        NSLog(@"ScreenW==%f  ScreenH==%f",ScreenW,ScreenH);
        [UIView animateWithDuration:0.5 animations:^{
            
            UIDevice *device = [UIDevice currentDevice];
            
            if (device.orientation == UIDeviceOrientationLandscapeLeft||device.orientation == UIDeviceOrientationLandscapeRight)
            {
            _backView.transform = [self getOrientation:(UIInterfaceOrientation)device.orientation];
            }else
            {
            _backView.transform = [self getOrientation:UIInterfaceOrientationLandscapeRight];
            }
            
            CGFloat viewH = ScreenW>ScreenH?ScreenW:ScreenH;
            CGFloat viewW = ScreenW<ScreenH?ScreenW:ScreenH;
            _backView.frame = CGRectMake(0, 0, viewW, viewH);
            
        }];
        _screen = YES;
    }
    [UIApplication sharedApplication].statusBarStyle = UIStatusBarStyleLightContent;
    [[UIApplication sharedApplication] setStatusBarHidden:NO];
}

-(BOOL)shouldAutorotate{
    return NO;
}

- (UIInterfaceOrientationMask)supportedInterfaceOrientations{
    NSLog(@"222");
    return UIInterfaceOrientationMaskPortrait;
}
@end
